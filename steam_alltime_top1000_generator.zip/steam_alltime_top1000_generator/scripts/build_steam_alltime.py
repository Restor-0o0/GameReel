import csv, json, re, urllib.request, pathlib, collections, time

ROOT = pathlib.Path(__file__).resolve().parents[1]
DATA = ROOT / 'data'
DATA.mkdir(exist_ok=True)
URL = 'https://steamspy.com/api.php?request=all&page=0'
UA = 'IdeaGeneratorDataset/1.0 (+local research tool)'

TAG_MAP = {
    'FPS':'shooting','Shooter':'shooting','Third-Person Shooter':'shooting','Looter Shooter':'shooting','Hero Shooter':'shooting','Extraction Shooter':'extraction',
    'Bullet Hell':'bullet dodging','Bullet Heaven':'auto-combat survival','Crafting':'crafting','Building':'building','Base Building':'base building',
    'Automation':'automation','Resource Management':'resource management','Management':'management','Economy':'economy','Trading':'trading','Physics':'physics',
    'Destruction':'destruction','Driving':'driving','Racing':'racing','Fishing':'fishing','Farming Sim':'farming','Hunting':'hunting','Creature Collector':'creature collection',
    'Survival':'survival','Survival Horror':'survival','Open World':'exploration','Exploration':'exploration','Dungeon Crawler':'dungeon crawling','Platformer':'platforming',
    'Precision Platformer':'platforming','Puzzle':'puzzles','Investigation':'investigation','Stealth':'stealth','Tower Defense':'tower defense','Colony Sim':'colony management',
    'City Builder':'city building','Life Sim':'life simulation','Roguelike':'run-based progression','Roguelite':'run-based progression','Action Roguelike':'run-based progression',
    'Roguelike Deckbuilder':'deckbuilding','Deckbuilding':'deckbuilding','Card Game':'card play','Card Battler':'card combat','Turn-Based Combat':'turn-based combat',
    'Turn-Based Strategy':'turn-based strategy','Turn-Based Tactics':'turn-based tactics','Hack and Slash':'melee combat','Souls-like':'melee combat','Combat':'combat',
    'Sandbox':'sandbox','Story Rich':'narrative','Choices Matter':'choice-driven narrative','Visual Novel':'visual novel','Rhythm':'rhythm','Music':'rhythm',
    'Multiplayer':'multiplayer','Co-op':'co-op','Online Co-Op':'co-op','PvP':'pvp','PvE':'pve','Singleplayer':'singleplayer','Character Customization':'character customization',
    'Moddable':'modding','Procedural Generation':'procedural generation','Inventory Management':'inventory management','Time Management':'time management','Cooking':'cooking',
    'Transportation':'transportation','Flight':'flight','Social Deduction':'social deduction','Horror':'horror','Immersive Sim':'immersive simulation','Idler':'idle progression',
    'Incremental':'incremental progression','Typing':'typing','Match 3':'match-3','Metroidvania':'metroidvania progression','Beat \'em up':'beat-em-up combat'
}

def fetch_json(url):
    req = urllib.request.Request(url, headers={'User-Agent': UA})
    with urllib.request.urlopen(req, timeout=120) as r:
        return json.load(r)

def owner_bounds(text):
    nums = [int(x.replace(',', '').strip()) for x in re.findall(r'[\d,]+', text or '')]
    if len(nums) >= 2: return nums[0], nums[1]
    if len(nums) == 1: return nums[0], nums[0]
    return 0, 0

def detect_visual(tags):
    t=set(tags)
    if 'Pixel Graphics' in t: return 'pixel art 2D'
    if 'Voxel' in t: return 'voxel 3D'
    if 'Hand-drawn' in t: return 'hand-drawn 2D'
    if 'Anime' in t: return 'anime stylized'
    if '2.5D' in t: return '2.5D'
    if 'Cartoony' in t or 'Cartoon' in t: return 'cartoon stylized'
    if 'Realistic' in t: return 'realistic 3D'
    if 'Low-Poly' in t: return 'low-poly 3D'
    if 'Minimalist' in t: return 'minimalist'
    if 'Psychedelic' in t or 'Surreal' in t: return 'surreal stylized'
    if '3D' in t: return 'stylized/standard 3D'
    if '2D' in t: return 'stylized/standard 2D'
    return 'infer from reference image'

def detect_camera(tags):
    t=set(tags)
    if 'First-Person' in t: return 'first-person'
    if 'Third Person' in t or 'Third-Person Shooter' in t: return 'third-person'
    if 'Top-Down' in t: return 'top-down'
    if 'Isometric' in t: return 'isometric'
    if 'Side Scroller' in t or 'Side-Scrolling' in t: return 'side-view'
    return 'unspecified / infer from game'

def player_mode(tags):
    t=set(tags)
    if 'Co-op' in t or 'Online Co-Op' in t: return 'co-op'
    if 'Massively Multiplayer' in t: return 'massively multiplayer'
    if 'Multiplayer' in t or 'PvP' in t: return 'multiplayer'
    if 'Singleplayer' in t: return 'singleplayer'
    return 'unspecified'

def mechanics(tags):
    out=[]
    for tag in tags:
        m=TAG_MAP.get(tag)
        if m and m not in out: out.append(m)
    if not out: out=[x.lower() for x in tags[:5]]
    return out

def safe_name(s):
    s=re.sub(r'[^A-Za-z0-9_-]+','_',s or '').strip('_')
    return s[:80] or 'game'

def main():
    raw = fetch_json(URL)
    rows=[]
    for key, x in raw.items():
        appid=str(x.get('appid') or key)
        if appid == '999999':
            continue
        lo, hi = owner_bounds(x.get('owners',''))
        tags_obj=x.get('tags') or {}
        if isinstance(tags_obj, dict):
            tags=[k for k,_ in sorted(tags_obj.items(), key=lambda kv: kv[1], reverse=True)]
        elif isinstance(tags_obj, list):
            tags=tags_obj
        else:
            tags=[]
        rows.append((lo,hi,appid,x,tags))
    rows.sort(key=lambda r:(r[0],r[1], int(r[3].get('positive') or 0)+int(r[3].get('negative') or 0)), reverse=True)
    rows=rows[:1000]

    games=[]
    for rank,(_,__,appid,x,tags) in enumerate(rows,1):
        mechs=mechanics(tags)
        title=x.get('name') or f'App {appid}'
        pos=int(x.get('positive') or 0); neg=int(x.get('negative') or 0)
        total=pos+neg
        game={
            'library':'steam_alltime_owners','source_rank':rank,'appid':appid,'title':title,
            'developer':x.get('developer',''),'publisher':x.get('publisher',''),'genre':x.get('genre',''),
            'steam_tags':tags,'core_mechanics':mechs[:3],'extra_mechanics':mechs[3:8],
            'visual_style':detect_visual(tags),'camera':detect_camera(tags),'player_mode':player_mode(tags),
            'owners':x.get('owners',''),'average_playtime_forever_min':x.get('average_forever',0),
            'median_playtime_forever_min':x.get('median_forever',0),'ccu_yesterday':x.get('ccu',0),
            'positive_reviews':pos,'negative_reviews':neg,'review_score_pct':round(pos*100/total,2) if total else None,
            'price_cents':x.get('price',0),'languages':x.get('languages',''),
            'store_url':f'https://store.steampowered.com/app/{appid}/',
            'header_image_url':f'https://cdn.akamai.steamstatic.com/steam/apps/{appid}/header.jpg',
            'local_image':f'images/{rank:04d}_{safe_name(title)}.jpg'
        }
        games.append(game)

    payload={'dataset':'Steam all-time top 1000 by owners','source_url':URL,'ranking_note':'SteamSpy request=all&page=0; documented as 1000 games sorted by owners.','games':games}
    (DATA/'games_1000.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8')

    fields=['library','source_rank','appid','title','developer','publisher','genre','steam_tags','core_mechanics','extra_mechanics','visual_style','camera','player_mode','owners','average_playtime_forever_min','median_playtime_forever_min','ccu_yesterday','positive_reviews','negative_reviews','review_score_pct','price_cents','languages','store_url','header_image_url','local_image']
    with (DATA/'games_1000.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields); w.writeheader()
        for g in games:
            r=dict(g)
            for k in ('steam_tags','core_mechanics','extra_mechanics'): r[k]=' | '.join(r[k])
            w.writerow(r)

    counters={k:collections.Counter() for k in ['core','extra','graphics','camera','players','genre']}
    for g in games:
        counters['core'].update(g['core_mechanics']); counters['extra'].update(g['extra_mechanics'])
        counters['graphics'][g['visual_style']]+=1; counters['camera'][g['camera']]+=1; counters['players'][g['player_mode']]+=1
        for genre in [z.strip() for z in (g['genre'] or '').split(',') if z.strip()]: counters['genre'][genre]+=1
    def items(c, cap=20): return [{'label':k,'weight':max(1,min(cap,v))} for k,v in c.most_common()]
    reels={'version':3,'library':'steam_alltime_owners','source_games':len(games),'reels':[
        {'id':'core','label_ru':'КОР','items':items(counters['core'])},
        {'id':'secondary','label_ru':'ДОП. МЕХАНИКА','items':items(counters['extra'],15)},
        {'id':'genre','label_ru':'ЖАНР','items':items(counters['genre'])},
        {'id':'graphics','label_ru':'ГРАФИКА','items':items(counters['graphics'])},
        {'id':'camera','label_ru':'КАМЕРА','items':items(counters['camera'])},
        {'id':'players','label_ru':'ИГРОКИ','items':items(counters['players'])},
        {'id':'reference_game','label_ru':'ИГРА-РЕФЕРЕНС','items':[{'label':g['title'],'appid':g['appid'],'image':g['local_image'],'weight':1} for g in games]}
    ]}
    (DATA/'reels_from_1000.json').write_text(json.dumps(reels,ensure_ascii=False,indent=2),encoding='utf-8')
    with (DATA/'images_manifest.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.writer(f); w.writerow(['rank','appid','title','url','local_file'])
        for g in games: w.writerow([g['source_rank'],g['appid'],g['title'],g['header_image_url'],g['local_image']])
    print(f'Built {len(games)} Steam games.')

if __name__=='__main__':
    main()
