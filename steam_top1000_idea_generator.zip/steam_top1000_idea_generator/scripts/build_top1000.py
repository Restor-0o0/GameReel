import csv, json, re, urllib.request, pathlib, collections, sys
ROOT = pathlib.Path(__file__).resolve().parents[1]
DATA = ROOT/'data'
DATA.mkdir(exist_ok=True)
SOURCE_URL='https://raw.githubusercontent.com/preethichelli/GameSense/main/steam_games_2026.csv'
RAW=DATA/'steam_top1000_raw.csv'

TAG_MAP = {
'FPS':'shooting','Shooter':'shooting','Third-Person Shooter':'shooting','Looter Shooter':'shooting','Hero Shooter':'shooting','Extraction Shooter':'extraction','Bullet Hell':'bullet dodging',
'Crafting':'crafting','Building':'building','Base Building':'base building','Automation':'automation','Resource Management':'resource management','Management':'management','Economy':'economy','Trading':'trading',
'Physics':'physics','Destruction':'destruction','Driving':'driving','Racing':'racing','Fishing':'fishing','Farming Sim':'farming','Hunting':'hunting','Creature Collector':'creature collection',
'Survival':'survival','Survival Horror':'survival','Open World':'exploration','Exploration':'exploration','Dungeon Crawler':'dungeon crawling','Platformer':'platforming','Precision Platformer':'platforming',
'Puzzle':'puzzles','Investigation':'investigation','Stealth':'stealth','Tower Defense':'tower defense','Colony Sim':'colony management','City Builder':'city building','Life Sim':'life simulation',
'Roguelike':'run-based progression','Roguelite':'run-based progression','Roguelike Deckbuilder':'deckbuilding','Deckbuilding':'deckbuilding','Card Game':'card play','Card Battler':'card combat',
'Turn-Based Combat':'turn-based combat','Turn-Based Strategy':'turn-based strategy','Turn-Based Tactics':'turn-based tactics','Hack and Slash':'melee combat','Souls-like':'melee combat','Combat':'combat',
'Sandbox':'sandbox','Story Rich':'narrative','Choices Matter':'choice-driven narrative','Visual Novel':'visual novel','Rhythm':'rhythm','Music':'rhythm',
'Multiplayer':'multiplayer','Co-op':'co-op','Online Co-Op':'co-op','PvP':'pvp','PvE':'pve','Singleplayer':'singleplayer','Character Customization':'character customization','Moddable':'modding',
'Procedural Generation':'procedural generation','Inventory Management':'inventory management','Time Management':'time management','Cooking':'cooking','Transportation':'transportation','Flight':'flight'
}

def detect_visual(tags):
    t=set(tags)
    if 'Pixel Graphics' in t: return 'pixel art 2D'
    if 'Voxel' in t: return 'voxel 3D'
    if 'Anime' in t: return 'anime stylized'
    if 'Hand-drawn' in t: return 'hand-drawn 2D'
    if '2D' in t and '3D' in t: return 'mixed 2D/3D'
    if '2.5D' in t: return '2.5D'
    if 'Cartoony' in t or 'Cartoon' in t: return 'cartoon stylized'
    if 'Realistic' in t: return 'realistic 3D'
    if 'Psychedelic' in t or 'Surreal' in t: return 'surreal stylized'
    if '3D' in t: return 'stylized/standard 3D'
    if '2D' in t: return 'stylized/standard 2D'
    return 'unspecified / infer from reference image'

def detect_camera(tags):
    t=set(tags)
    if 'First-Person' in t: return 'first-person'
    if 'Third Person' in t or 'Third-Person Shooter' in t: return 'third-person'
    if 'Top-Down' in t: return 'top-down'
    if 'Isometric' in t: return 'isometric'
    if 'Side Scroller' in t or 'Side-Scrolling' in t: return 'side-view'
    return 'unspecified / infer from game'

def player_mode(tags):
    t=set(tags)
    if 'Co-op' in t or 'Online Co-Op' in t: return 'co-op'
    if 'Multiplayer' in t or 'PvP' in t: return 'multiplayer'
    if 'Singleplayer' in t: return 'singleplayer'
    return 'unspecified'

def scope_est(tags, reviews):
    expensive={'Open World','MMORPG','Massively Multiplayer','Realistic','Cinematic','City Builder','Colony Sim','Base Building','Online Co-Op','Multiplayer','VR'}
    score=sum(1 for x in tags if x in expensive)
    if score>=5: return 'very_large'
    if score>=3: return 'large'
    if score>=1: return 'medium'
    return 'small'

def mechanics(tags):
    out=[]
    for tag in tags:
        m=TAG_MAP.get(tag)
        if m and m not in out: out.append(m)
    # fallback preserves useful Steam tags as generator atoms
    if not out:
        out=[x.lower() for x in tags[:5]]
    return out

def download():
    print('Downloading source dataset...')
    req=urllib.request.Request(SOURCE_URL, headers={'User-Agent':'Mozilla/5.0'})
    with urllib.request.urlopen(req, timeout=60) as r:
        RAW.write_bytes(r.read())

def main():
    if '--offline' not in sys.argv:
        download()
    if not RAW.exists():
        raise SystemExit('Raw CSV missing. Run once with internet or place it at data/steam_top1000_raw.csv')
    games=[]
    with RAW.open(encoding='utf-8-sig', newline='') as f:
        for rank,row in enumerate(csv.DictReader(f), start=1):
            tags=[x.strip() for x in (row.get('All_Tags') or '').split(';') if x.strip()]
            appid=str(row.get('AppID') or '').strip()
            title=(row.get('Name') or '').strip()
            mechs=mechanics(tags)
            core=mechs[:3]
            extra=mechs[3:8]
            game={
                'source_rank':rank,'appid':appid,'title':title,
                'primary_genre':row.get('Primary_Genre',''),
                'steam_tags':tags,
                'core_mechanics':core,'extra_mechanics':extra,
                'visual_style':detect_visual(tags),'camera':detect_camera(tags),
                'player_mode':player_mode(tags),'production_scope_estimate':scope_est(tags,row.get('Total_Reviews')),
                'review_score_pct':row.get('Review_Score_Pct',''),'total_reviews':row.get('Total_Reviews',''),'estimated_owners':row.get('Estimated_Owners',''),
                'steam_url':f'https://store.steampowered.com/app/{appid}/' if appid else '',
                'header_image_url':f'https://cdn.akamai.steamstatic.com/steam/apps/{appid}/header.jpg' if appid else '',
                'local_image':f'images/{rank:04d}_{re.sub(r"[^A-Za-z0-9_-]+","_",title).strip("_")}.jpg'
            }
            games.append(game)
    if len(games)!=1000:
        print(f'WARNING: expected 1000 games, got {len(games)}')
    (DATA/'games_1000.json').write_text(json.dumps({'source_url':SOURCE_URL,'games':games},ensure_ascii=False,indent=2),encoding='utf-8')
    fields=['source_rank','appid','title','primary_genre','steam_tags','core_mechanics','extra_mechanics','visual_style','camera','player_mode','production_scope_estimate','review_score_pct','total_reviews','estimated_owners','steam_url','header_image_url','local_image']
    with (DATA/'games_1000.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields); w.writeheader()
        for g in games:
            r=dict(g); r['steam_tags']=' | '.join(r['steam_tags']); r['core_mechanics']=' | '.join(r['core_mechanics']); r['extra_mechanics']=' | '.join(r['extra_mechanics']); w.writerow(r)
    # reels from full 1000
    core=collections.Counter(); extra=collections.Counter(); graphics=collections.Counter(); cameras=collections.Counter(); genres=collections.Counter(); modes=collections.Counter()
    for g in games:
        core.update(g['core_mechanics']); extra.update(g['extra_mechanics']); graphics[g['visual_style']]+=1; cameras[g['camera']]+=1; genres[g['primary_genre']]+=1; modes[g['player_mode']]+=1
    reels={
      'version':2,
      'source_games':len(games),
      'reels':[
        {'id':'core','label_ru':'КОР','items':[{'label':k,'weight':max(1,min(20,v))} for k,v in core.most_common()]},
        {'id':'secondary','label_ru':'ДОП. МЕХАНИКА','items':[{'label':k,'weight':max(1,min(15,v))} for k,v in extra.most_common()]},
        {'id':'genre','label_ru':'ЖАНРОВАЯ ОСНОВА','items':[{'label':k,'weight':max(1,min(20,v))} for k,v in genres.most_common()]},
        {'id':'graphics','label_ru':'ГРАФИКА','items':[{'label':k,'weight':max(1,min(20,v))} for k,v in graphics.most_common()]},
        {'id':'camera','label_ru':'КАМЕРА','items':[{'label':k,'weight':max(1,min(20,v))} for k,v in cameras.most_common()]},
        {'id':'players','label_ru':'ИГРОКИ','items':[{'label':k,'weight':max(1,min(20,v))} for k,v in modes.most_common()]},
        {'id':'reference_game','label_ru':'ИГРА-РЕФЕРЕНС','items':[{'label':g['title'],'appid':g['appid'],'image':g['local_image'],'weight':1} for g in games]}
      ]
    }
    (DATA/'reels_from_1000.json').write_text(json.dumps(reels,ensure_ascii=False,indent=2),encoding='utf-8')
    with (DATA/'images_manifest.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.writer(f); w.writerow(['rank','appid','title','url','local_file'])
        for g in games: w.writerow([g['source_rank'],g['appid'],g['title'],g['header_image_url'],g['local_image']])
    print('Built',len(games),'games')

if __name__=='__main__': main()
