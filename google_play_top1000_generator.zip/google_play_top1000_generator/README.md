# Google Play Top 1000 — Idea Generator Library

Отдельная мобильная библиотека для генератора игровых идей.

Это **не официальный Google all-time chart** — такого единого публичного топа нет. Набор строится из 2.3M+ Google Play приложений и выбирает 1000 игр с наибольшим `Maximum Installs` (далее Rating Count и Rating).

## Быстрый запуск (Windows)

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\build_all.ps1
```

Скрипт:

1. скачает публичный Kaggle dataset;
2. отберёт top-1000 игр;
3. создаст JSON/CSV и барабаны;
4. попробует скачать reference image для каждой игры через Google Play scraper.

Если Kaggle не скачивается автоматически, вручную положи `Google-Playstore.csv` в `data/raw/` и запусти `build_all.ps1` снова.

Поддерживаются Reference Spin и безусловный `Pin` в левую замороженную область — см. `docs/IDEA_GENERATOR_SPEC.md`.
