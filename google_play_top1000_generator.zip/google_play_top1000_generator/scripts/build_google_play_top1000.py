import csv, json, pathlib, re, collections, sys

ROOT=pathlib.Path(__file__).resolve().parents[1]
DATA=ROOT/'data'; DATA.mkdir(exist_ok=True)
RAW=DATA/'raw'/'Google-Playstore.csv'
GAME_CATEGORIES={
    'Action','Adventure','Arcade','Board','Card','Casino','Casual','Educational','Music','Puzzle','Racing','Role Playing','Simulation','Sports','Strategy','Trivia','Word',
    'GAME_ACTION','GAME_ADVENTURE','GAME_ARCADE','GAME_BOARD','GAME_CARD','GAME_CASINO','GAME_CASUAL','GAME_EDUCATIONAL','GAME_MUSIC','GAME_PUZZLE','GAME_RACING','GAME_ROLE_PLAYING','GAME_SIMULATION','GAME_SPORTS','GAME_STRATEGY','GAME_TRIVIA','GAME_WORD','Game'
}
CAT_TO_MECH={
    'Action':['combat','action'],'Adventure':['exploration','adventure'],'Arcade':['arcade loop','score attack'],'Board':['board-game rules'],'Card':['card play'],
    'Casino':['chance / gambling-like loop'],'Casual':['casual short sessions'],'Educational':['learning mechanics'],'Music':['rhythm / music'],'Puzzle':['puzzles'],
    'Racing':['racing','driving'],'Role Playing':['rpg progression','character growth'],'Simulation':['simulation'],'Sports':['sports mechanics'],
    'Strategy':['strategy','resource decisions'],'Trivia':['quiz / knowledge'],'Word':['word puzzles']
}

def norm_cat(c):
    c=(c or '').strip()
    if c.startswith('GAME_'):
        c=c[5:].replace('_',' ').title().replace('Role Playing','Role Playing')
    return c

def intval(v):
    if v is None: return 0
    s=str(v).replace(',','').replace('+','').strip()
    try: return int(float(s))
    except: return 0

def floatval(v):
    try: return float(v)
    except: return 0.0

def boolval(v):
    return str(v).strip().lower() in {'true','1','yes'}

def safe_name(s):
    return (re.sub(r'[^A-Za-z0-9_-]+','_',s or '').strip('_')[:80] or 'game')

def is_game(row):
    c=(row.get('Category') or '').strip()
    return c in GAME_CATEGORIES or c.startswith('GAME_')

def main():
    if not RAW.exists():
        raise SystemExit('Missing data/raw/Google-Playstore.csv. Run scripts/fetch_dataset.ps1 first, or place the Kaggle CSV there manually.')
    best={}
    with RAW.open(encoding='utf-8',errors='replace',newline='') as f:
        for row in csv.DictReader(f):
            if not is_game(row): continue
            appid=(row.get('App Id') or '').strip()
            if not appid: continue
            installs=intval(row.get('Maximum Installs') or row.get('Minimum Installs') or row.get('Installs'))
            ratings=intval(row.get('Rating Count'))
            rating=floatval(row.get('Rating'))
            score=(installs,ratings,rating)
            if appid not in best or score>best[appid][0]: best[appid]=(score,row)
    ranked=sorted(best.values(),key=lambda x:x[0],reverse=True)[:1000]
    games=[]
    for rank,(score,row) in enumerate(ranked,1):
        cat=norm_cat(row.get('Category'))
        mechs=CAT_TO_MECH.get(cat,[cat.lower()] if cat else ['mobile game'])
        appid=(row.get('App Id') or '').strip(); title=(row.get('App Name') or appid).strip()
        free=boolval(row.get('Free')); ads=boolval(row.get('Ad Supported')); iap=boolval(row.get('In App Purchases'))
        monet=[]
        monet.append('free-to-play' if free else 'premium')
        if ads: monet.append('ads')
        if iap: monet.append('in-app purchases')
        game={
            'library':'google_play_alltime_like','source_rank':rank,'app_id':appid,'title':title,'category':cat,
            'core_mechanics':mechs[:2],'extra_mechanics':[],
            'mobile_business_tags':monet,'visual_style':'infer from reference image','camera':'infer from reference image','player_mode':'unspecified',
            'rating':floatval(row.get('Rating')),'rating_count':intval(row.get('Rating Count')),
            'minimum_installs':intval(row.get('Minimum Installs') or row.get('Installs')),'maximum_installs':intval(row.get('Maximum Installs') or row.get('Installs')),
            'free':free,'price':row.get('Price',''),'currency':row.get('Currency',''),'content_rating':row.get('Content Rating',''),
            'ad_supported':ads,'in_app_purchases':iap,'editors_choice':boolval(row.get('Editors Choice')),
            'developer_id':row.get('Developer Id',''),'released':row.get('Released',''),'last_updated':row.get('Last Updated',''),
            'store_url':f'https://play.google.com/store/apps/details?id={appid}',
            'local_image':f'images/{rank:04d}_{safe_name(title)}.jpg'
        }
        games.append(game)
    payload={'dataset':'Google Play top 1000 games by cumulative installs (historical snapshot)','source':'gauthamp10/google-playstore-apps; June 2021 snapshot','ranking_note':'Game categories only; Maximum Installs desc, then Rating Count, then Rating.','games':games}
    (DATA/'games_1000.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8')
    fields=['library','source_rank','app_id','title','category','core_mechanics','extra_mechanics','mobile_business_tags','visual_style','camera','player_mode','rating','rating_count','minimum_installs','maximum_installs','free','price','currency','content_rating','ad_supported','in_app_purchases','editors_choice','developer_id','released','last_updated','store_url','local_image']
    with (DATA/'games_1000.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields); w.writeheader()
        for g in games:
            r=dict(g)
            for k in ('core_mechanics','extra_mechanics','mobile_business_tags'): r[k]=' | '.join(r[k])
            w.writerow(r)
    core=collections.Counter(); cats=collections.Counter(); monet=collections.Counter()
    for g in games:
        core.update(g['core_mechanics']); cats[g['category']]+=1; monet.update(g['mobile_business_tags'])
    def items(c,cap=20): return [{'label':k,'weight':max(1,min(cap,v))} for k,v in c.most_common() if k]
    reels={'version':3,'library':'google_play_alltime_like','source_games':len(games),'reels':[
        {'id':'core','label_ru':'КОР','items':items(core)},
        {'id':'genre','label_ru':'МОБИЛЬНЫЙ ЖАНР','items':items(cats)},
        {'id':'monetization','label_ru':'МОНЕТИЗАЦИЯ','items':items(monet)},
        {'id':'graphics','label_ru':'ГРАФИКА','items':[{'label':'take visual from reference image','weight':1}]},
        {'id':'reference_game','label_ru':'ИГРА-РЕФЕРЕНС','items':[{'label':g['title'],'app_id':g['app_id'],'image':g['local_image'],'weight':1} for g in games]}
    ]}
    (DATA/'reels_from_1000.json').write_text(json.dumps(reels,ensure_ascii=False,indent=2),encoding='utf-8')
    with (DATA/'images_manifest.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.writer(f); w.writerow(['rank','app_id','title','store_url','local_file'])
        for g in games: w.writerow([g['source_rank'],g['app_id'],g['title'],g['store_url'],g['local_image']])
    print('Built',len(games),'Google Play games')

if __name__=='__main__': main()
